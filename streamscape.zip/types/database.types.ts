export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          first_name: string
          last_name: string
          avatar_url: string | null
          bio: string | null
          location: string | null
          interests: string[] | null
          birth_date: string | null
          gender: string | null
          looking_for: string | null
        }
        Insert: {
          id: string
          created_at?: string
          updated_at?: string
          first_name: string
          last_name: string
          avatar_url?: string | null
          bio?: string | null
          location?: string | null
          interests?: string[] | null
          birth_date?: string | null
          gender?: string | null
          looking_for?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          first_name?: string
          last_name?: string
          avatar_url?: string | null
          bio?: string | null
          location?: string | null
          interests?: string[] | null
          birth_date?: string | null
          gender?: string | null
          looking_for?: string | null
        }
      }
      chats: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          user1_id: string
          user2_id: string
        }
        Insert: {
          id?: string
          created_at?: string
          updated_at?: string
          user1_id: string
          user2_id: string
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          user1_id?: string
          user2_id?: string
        }
      }
      messages: {
        Row: {
          id: string
          created_at: string
          chat_id: string
          sender_id: string
          content: string
          read: boolean
        }
        Insert: {
          id?: string
          created_at?: string
          chat_id: string
          sender_id: string
          content: string
          read?: boolean
        }
        Update: {
          id?: string
          created_at?: string
          chat_id?: string
          sender_id?: string
          content?: string
          read?: boolean
        }
      }
      subscriptions: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          user_id: string
          plan_id: string
          stripe_subscription_id: string | null
          status: string
          current_period_start: string
          current_period_end: string
          cancel_at_period_end: boolean
        }
        Insert: {
          id?: string
          created_at?: string
          updated_at?: string
          user_id: string
          plan_id: string
          stripe_subscription_id?: string | null
          status: string
          current_period_start: string
          current_period_end: string
          cancel_at_period_end?: boolean
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          user_id?: string
          plan_id?: string
          stripe_subscription_id?: string | null
          status?: string
          current_period_start?: string
          current_period_end?: string
          cancel_at_period_end?: boolean
        }
      }
      plans: {
        Row: {
          id: string
          name: string
          description: string | null
          price: number
          currency: string
          interval: string
          stripe_price_id: string | null
          features: Json | null
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          price: number
          currency: string
          interval: string
          stripe_price_id?: string | null
          features?: Json | null
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          price?: number
          currency?: string
          interval?: string
          stripe_price_id?: string | null
          features?: Json | null
        }
      }
      matches: {
        Row: {
          id: string
          created_at: string
          user1_id: string
          user2_id: string
          status: string
        }
        Insert: {
          id?: string
          created_at?: string
          user1_id: string
          user2_id: string
          status: string
        }
        Update: {
          id?: string
          created_at?: string
          user1_id?: string
          user2_id?: string
          status?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
