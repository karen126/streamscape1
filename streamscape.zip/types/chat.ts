export interface Message {
  id: string
  created_at: string
  chat_id: string
  sender_id: string
  content: string
  read: boolean
}

export interface Chat {
  id: string
  created_at: string
  updated_at: string
  user1_id: string
  user2_id: string
  otherUser?: {
    id: string
    first_name: string
    last_name: string
    avatar_url: string | null
  }
  lastMessage?: Message | null
}

export interface Profile {
  id: string
  created_at: string
  updated_at: string
  first_name: string
  last_name: string
  avatar_url: string | null
  bio: string | null
  location: string | null
  interests: string[] | null
  birth_date: string | null
  gender: string | null
  looking_for: string | null
}
