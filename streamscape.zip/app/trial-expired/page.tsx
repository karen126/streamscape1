"use client"

import Link from "next/link"
import { Clock, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function TrialExpiredPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4 py-12 dark:bg-gray-900">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-6">
            <Link
              className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text text-transparent"
              href="/"
            >
              StreamScape
            </Link>
          </div>
          <div className="mx-auto bg-red-100 dark:bg-red-900/30 rounded-full p-3 w-12 h-12 flex items-center justify-center mb-4">
            <Clock className="h-6 w-6 text-red-600 dark:text-red-400" />
          </div>
          <CardTitle className="text-2xl text-center">Your Free Trial Has Expired</CardTitle>
          <CardDescription className="text-center">
            Thank you for trying StreamScape! To continue enjoying our service, please choose a subscription plan.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg border p-4 bg-muted/50">
            <h3 className="font-medium mb-2">Why upgrade to a paid plan?</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>Connect with people who share your interests worldwide</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>Enjoy high-quality video calls with your matches</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>Access to all premium features based on your chosen plan</span>
              </li>
            </ul>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Link href="/pricing" className="w-full">
            <Button className="w-full bg-gradient-to-r from-blue-500 to-purple-600">
              View Subscription Plans
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
          <div className="text-center text-sm">
            Have questions?{" "}
            <Link className="underline" href="/contact">
              Contact Support
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
