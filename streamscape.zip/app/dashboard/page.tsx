"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Bell, MessageSquare, Search, Settings, User, Video, Heart, Filter } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

import { supabase } from "@/lib/supabase"
import { getCurrentUser } from "@/lib/auth"
import { getProfile, getUserMatches } from "@/lib/db"
import { getUserSubscription, hasActiveSubscription } from "@/lib/subscription"
import { DiscoverSection } from "@/components/dashboard/discover-section"
import { TrialBanner } from "./trial-banner"

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [subscription, setSubscription] = useState<any>(null)
  const [matches, setMatches] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false)
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("discover")
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    loadUserData()
  }, [])

  const loadUserData = async () => {
    try {
      const currentUser = await getCurrentUser()
      if (!currentUser) {
        router.push("/login")
        return
      }

      setUser(currentUser)

      // Load profile
      const userProfile = await getProfile(currentUser.id)
      setProfile(userProfile)

      // Load subscription
      const userSubscription = await getUserSubscription(currentUser.id)
      setSubscription(userSubscription)

      // Load matches
      const userMatches = await getUserMatches(currentUser.id)
      setMatches(userMatches)

      // Check if subscription is active
      const hasActive = await hasActiveSubscription(currentUser.id)
      if (!hasActive) {
        // If no active subscription, redirect to trial expired page after a delay
        setTimeout(() => {
          router.push("/trial-expired")
        }, 5000) // Give them 5 seconds to see the dashboard
      }
    } catch (error) {
      console.error("Error loading user data:", error)
      toast({
        title: "Error",
        description: "Failed to load user data. Please refresh the page.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    toast({
      title: "Search initiated",
      description: `Searching for "${searchQuery}"`,
    })
  }

  const getUserInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!user || !profile) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <p>Unable to load user data. Please try refreshing the page.</p>
          <Button onClick={() => window.location.reload()} className="mt-4">
            Refresh
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-4 md:px-6">
        <div className="flex items-center gap-2 font-semibold">
          <span className="text-xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text text-transparent">
            StreamScape
          </span>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <form className="relative hidden md:flex" onSubmit={handleSearch}>
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search..."
              className="w-64 rounded-lg bg-background pl-8 md:w-80"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </form>
          <Button variant="outline" size="icon" className="relative" onClick={() => setIsFilterModalOpen(true)}>
            <Filter className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute right-1 top-1 flex h-2 w-2 rounded-full bg-red-600" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setIsProfileModalOpen(true)}>
            <Settings className="h-5 w-5" />
          </Button>
          <Avatar className="cursor-pointer" onClick={() => setIsProfileModalOpen(true)}>
            <AvatarImage src={profile.avatar_url || "/placeholder.svg?height=32&width=32"} alt="User" />
            <AvatarFallback>{getUserInitials(profile.first_name, profile.last_name)}</AvatarFallback>
          </Avatar>
        </div>
      </header>

      <div className="grid flex-1 md:grid-cols-[240px_1fr]">
        <div className="hidden border-r bg-muted/40 md:block">
          <div className="flex h-full max-h-screen flex-col gap-2">
            <div className="flex-1 overflow-auto py-2">
              <nav className="grid items-start px-2 text-sm font-medium">
                <Button
                  variant={activeTab === "discover" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("discover")}
                >
                  <User className="h-4 w-4 mr-2" />
                  Discover
                </Button>
                <Button
                  variant={activeTab === "matches" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("matches")}
                >
                  <Heart className="h-4 w-4 mr-2" />
                  Matches
                </Button>
                <Button
                  variant={activeTab === "profile" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("profile")}
                >
                  <User className="h-4 w-4 mr-2" />
                  My Profile
                </Button>
                <Button variant="ghost" className="justify-start" onClick={() => router.push("/dashboard/messages")}>
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Messages
                </Button>
                <Button variant="ghost" className="justify-start" onClick={() => router.push("/dashboard/calls")}>
                  <Video className="h-4 w-4 mr-2" />
                  Video Calls
                </Button>
                <Button variant="ghost" className="justify-start" onClick={() => router.push("/dashboard/settings")}>
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </nav>
            </div>
          </div>
        </div>

        <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
          {subscription && (
            <TrialBanner trialStartDate={new Date(subscription.current_period_start)} subscription={subscription} />
          )}

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="discover">Discover</TabsTrigger>
              <TabsTrigger value="matches">Matches ({matches.length})</TabsTrigger>
              <TabsTrigger value="profile">My Profile</TabsTrigger>
            </TabsList>

            <TabsContent value="discover" className="mt-6">
              <DiscoverSection currentUserId={user.id} />
            </TabsContent>

            <TabsContent value="matches" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {matches.length > 0 ? (
                  matches.map((match) => (
                    <Card key={match.id} className="overflow-hidden transition-all duration-200 hover:shadow-lg">
                      <div className="aspect-video relative bg-gradient-to-r from-blue-100 to-purple-100">
                        <Avatar className="w-full h-full rounded-none">
                          <AvatarImage
                            src={match.profile?.avatar_url || "/placeholder.svg?height=200&width=400"}
                            alt={`${match.profile?.first_name} ${match.profile?.last_name}`}
                            className="object-cover"
                          />
                          <AvatarFallback className="w-full h-full rounded-none text-4xl">
                            {getUserInitials(match.profile?.first_name || "", match.profile?.last_name || "")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="absolute top-2 right-2">
                          <Badge className="bg-green-500">Match!</Badge>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="font-semibold text-lg">
                            {`${match.profile?.first_name} ${match.profile?.last_name}`}
                          </h3>
                          <Badge variant="outline">New Match</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{match.profile?.bio || "No bio available"}</p>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1"
                            onClick={() => router.push(`/dashboard/messages?user=${match.otherUserId}`)}
                          >
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Message
                          </Button>
                          <Button size="sm" className="flex-1">
                            <Video className="h-4 w-4 mr-2" />
                            Video Call
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-full flex flex-col items-center justify-center py-12 text-center">
                    <Heart className="h-16 w-16 text-muted-foreground mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No matches yet</h3>
                    <p className="text-muted-foreground max-w-md">
                      Start liking profiles in the Discover tab to find your matches!
                    </p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="profile" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center gap-4 text-center">
                      <Avatar className="h-24 w-24">
                        <AvatarImage src={profile.avatar_url || "/placeholder.svg?height=96&width=96"} alt="User" />
                        <AvatarFallback>{getUserInitials(profile.first_name, profile.last_name)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-2xl font-bold">{`${profile.first_name} ${profile.last_name}`}</h3>
                        <p className="text-sm text-muted-foreground">
                          {subscription?.status === "trialing" ? "Free Trial" : subscription?.plans?.name || "No Plan"}
                        </p>
                      </div>
                      <div className="grid grid-cols-3 gap-4 w-full">
                        <div className="text-center">
                          <p className="text-2xl font-bold">{matches.length}</p>
                          <p className="text-xs text-muted-foreground">Matches</p>
                        </div>
                        <div className="text-center">
                          <p className="text-2xl font-bold">24</p>
                          <p className="text-xs text-muted-foreground">Messages</p>
                        </div>
                        <div className="text-center">
                          <p className="text-2xl font-bold">120</p>
                          <p className="text-xs text-muted-foreground">Call Minutes</p>
                        </div>
                      </div>
                      <div className="flex gap-2 w-full">
                        <Button variant="outline" className="flex-1">
                          Edit Profile
                        </Button>
                        <Button className="flex-1" onClick={() => router.push("/pricing")}>
                          Upgrade Plan
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold mb-4">About Me</h3>
                    <p className="text-sm text-muted-foreground mb-6">
                      {profile.bio || "No bio available. Edit your profile to add a bio."}
                    </p>
                    <h4 className="font-medium mb-2">My Interests</h4>
                    <div className="flex flex-wrap gap-2 mb-6">
                      {profile.interests && profile.interests.length > 0 ? (
                        profile.interests.map((interest: string, index: number) => (
                          <Badge key={index} variant="secondary">
                            {interest}
                          </Badge>
                        ))
                      ) : (
                        <p className="text-sm text-muted-foreground">No interests added yet.</p>
                      )}
                    </div>
                    <h4 className="font-medium mb-2">Looking For</h4>
                    <p className="text-sm text-muted-foreground">{profile.looking_for || "Not specified"}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>

      {/* Filter Modal */}
      <Dialog open={isFilterModalOpen} onOpenChange={setIsFilterModalOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Filter Results</DialogTitle>
            <DialogDescription>Customize your search preferences</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <label>Age Range</label>
              <div className="flex items-center gap-4">
                <Input type="number" placeholder="Min" min="18" max="100" className="w-20" />
                <span>to</span>
                <Input type="number" placeholder="Max" min="18" max="100" className="w-20" />
              </div>
            </div>
            <div className="space-y-2">
              <label>Distance (miles)</label>
              <Input type="number" placeholder="Maximum distance" min="1" max="500" />
            </div>
          </div>
          <div className="flex justify-between">
            <Button variant="outline" onClick={() => setIsFilterModalOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                setIsFilterModalOpen(false)
                toast({
                  title: "Filters applied",
                  description: "Your search preferences have been updated",
                })
              }}
            >
              Apply Filters
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Profile Settings Modal */}
      <Dialog open={isProfileModalOpen} onOpenChange={setIsProfileModalOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Profile Settings</DialogTitle>
            <DialogDescription>Manage your account and preferences</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={profile.avatar_url || "/placeholder.svg?height=64&width=64"} alt="User" />
                <AvatarFallback>{getUserInitials(profile.first_name, profile.last_name)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{`${profile.first_name} ${profile.last_name}`}</p>
                <p className="text-sm text-muted-foreground">
                  {subscription?.status === "trialing" ? "Free Trial" : subscription?.plans?.name || "No Plan"}
                </p>
              </div>
            </div>
            <div className="space-y-1">
              <label>Subscription</label>
              <div className="flex items-center justify-between rounded-md border p-3">
                <div>
                  <p className="font-medium">
                    {subscription?.status === "trialing" ? "Free Trial" : subscription?.plans?.name || "No Plan"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {subscription
                      ? `Expires ${new Date(subscription.current_period_end).toLocaleDateString()}`
                      : "No active subscription"}
                  </p>
                </div>
                <Button size="sm" onClick={() => router.push("/pricing")}>
                  Upgrade
                </Button>
              </div>
            </div>
          </div>
          <div className="flex justify-between">
            <Button variant="outline" onClick={() => setIsProfileModalOpen(false)}>
              Close
            </Button>
            <Button
              variant="destructive"
              onClick={async () => {
                await supabase.auth.signOut()
                router.push("/")
              }}
            >
              Log Out
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
