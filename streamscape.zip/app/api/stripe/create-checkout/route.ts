import { type NextRequest, NextResponse } from "next/server"
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { stripe, createOrUpdateCustomer } from "@/lib/stripe"

export async function POST(request: NextRequest) {
  try {
    const { priceId, planName } = await request.json()

    console.log("🛒 Creando checkout session:", { priceId, planName })

    if (!priceId) {
      return NextResponse.json({ error: "Price ID is required" }, { status: 400 })
    }

    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore })

    // Get the current user
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      console.error("❌ Usuario no autenticado:", authError)
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    console.log("👤 Usuario autenticado:", user.id)

    // Get user profile
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single()

    if (profileError || !profile) {
      console.error("❌ Perfil no encontrado:", profileError)
      return NextResponse.json({ error: "Profile not found" }, { status: 404 })
    }

    console.log("📋 Perfil encontrado:", profile)

    // Create or get Stripe customer
    const customerId = await createOrUpdateCustomer(user.id, user.email!, `${profile.first_name} ${profile.last_name}`)

    console.log("💳 Cliente de Stripe:", customerId)

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: `${request.nextUrl.origin}/dashboard?success=true`,
      cancel_url: `${request.nextUrl.origin}/pricing?canceled=true`,
      metadata: {
        userId: user.id,
        planName: planName || "Unknown",
      },
      allow_promotion_codes: true,
      billing_address_collection: "required",
    })

    console.log("✅ Sesión de checkout creada:", session.id)

    return NextResponse.json({ sessionId: session.id, url: session.url })
  } catch (error) {
    console.error("💥 Error creating checkout session:", error)
    return NextResponse.json(
      { error: `Internal server error: ${error instanceof Error ? error.message : "Unknown error"}` },
      { status: 500 },
    )
  }
}
