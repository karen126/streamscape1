import Link from "next/link"
import { Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { getStripePlans } from "@/lib/stripe"

export default async function PricingPage() {
  const plans = await getStripePlans()

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center">
        <Link className="flex items-center justify-center" href="/">
          <span className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text text-transparent">
            StreamScape
          </span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/#features">
            Features
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/pricing">
            Pricing
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/#about">
            About
          </Link>
        </nav>
        <div className="ml-4 flex items-center gap-2">
          <Link href="/login">
            <Button variant="outline" size="sm">
              Log In
            </Button>
          </Link>
          <Link href="/signup">
            <Button size="sm">Sign Up</Button>
          </Link>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Choose Your Plan</h1>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Select the perfect subscription that fits your needs and budget
                </p>
              </div>
            </div>
            <div className="mt-6 mb-4 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 p-4 rounded-lg border border-blue-100 dark:border-blue-800 max-w-3xl mx-auto">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-lg font-semibold">Try StreamScape Free for 3 Days</h3>
                  <p className="text-sm text-muted-foreground">
                    Get full access to all features with no commitment. No credit card required.
                  </p>
                </div>
                <Link href="/signup?plan=trial">
                  <Button className="bg-gradient-to-r from-blue-500 to-purple-600">Start Free Trial</Button>
                </Link>
              </div>
            </div>
            <div className="grid gap-6 pt-12 lg:grid-cols-3 lg:gap-8">
              {plans.map((plan, index) => (
                <Card
                  key={plan.id}
                  className={`flex flex-col ${index === 1 ? "border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950" : ""}`}
                >
                  <CardHeader>
                    {index === 1 && (
                      <div className="inline-block rounded-full bg-gradient-to-r from-blue-500 to-purple-600 px-3 py-1 text-xs font-medium text-white">
                        POPULAR
                      </div>
                    )}
                    <CardTitle>{plan.name}</CardTitle>
                    <CardDescription>
                      {plan.name === "Basic" && "Perfect for casual users"}
                      {plan.name === "Premium" && "Best for active users"}
                      {plan.name === "Ultimate" && "For serious connections"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="grid gap-4">
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl font-bold">${plan.price}</span>
                      <span className="text-sm font-medium text-gray-500 dark:text-gray-400">/{plan.interval}</span>
                    </div>
                    <ul className="grid gap-2 text-sm">
                      {plan.features &&
                        Array.isArray(plan.features) &&
                        plan.features.map((feature: string, featureIndex: number) => (
                          <li key={featureIndex} className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-green-500" />
                            <span>{feature}</span>
                          </li>
                        ))}
                    </ul>
                  </CardContent>
                  <CardFooter className="mt-auto pt-4">
                    <div className="w-full space-y-2">
                      <Link
                        href={`/signup?plan=${plan.name.toLowerCase()}&price_id=${plan.stripe_price_id}`}
                        className="w-full"
                      >
                        <Button
                          className={`w-full ${index === 1 ? "bg-gradient-to-r from-blue-500 to-purple-600" : ""}`}
                        >
                          Subscribe Now
                        </Button>
                      </Link>
                      <p className="text-xs text-center">
                        or{" "}
                        <Link href="/signup?plan=trial" className="text-blue-500 hover:underline">
                          try free for 3 days
                        </Link>
                      </p>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
            <div className="mt-12 text-center">
              <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
              <div className="mt-6 grid gap-6 md:grid-cols-2 lg:gap-12">
                <div className="text-left">
                  <h3 className="text-lg font-medium">Can I cancel my subscription anytime?</h3>
                  <p className="mt-2 text-gray-500">
                    Yes, you can cancel your subscription at any time. Your plan will remain active until the end of
                    your billing period.
                  </p>
                </div>
                <div className="text-left">
                  <h3 className="text-lg font-medium">How does the free trial work?</h3>
                  <p className="mt-2 text-gray-500">
                    Our free trial gives you full access to all features for 3 days. After the trial period ends, you'll
                    need to select a paid plan to continue using StreamScape.
                  </p>
                </div>
                <div className="text-left">
                  <h3 className="text-lg font-medium">How do video calls work?</h3>
                  <p className="mt-2 text-gray-500">
                    Our platform uses secure, high-quality video technology. Simply click the video icon in any
                    conversation to start a call.
                  </p>
                </div>
                <div className="text-left">
                  <h3 className="text-lg font-medium">Is my information secure?</h3>
                  <p className="mt-2 text-gray-500">
                    We take privacy seriously. All conversations are encrypted, and we never share your personal
                    information with third parties.
                  </p>
                </div>
                <div className="text-left">
                  <h3 className="text-lg font-medium">What payment methods do you accept?</h3>
                  <p className="mt-2 text-gray-500">
                    We accept all major credit cards, PayPal, and various local payment methods depending on your
                    region.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500 dark:text-gray-400">© 2025 StreamScape. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}
