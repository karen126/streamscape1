export default function Head() {
  return (
    <>
      <script src="/sw-register.js" async defer />
    </>
  )
}
