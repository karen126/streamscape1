import { supabase } from "./supabase"

// Verificar si el usuario tiene una suscripción activa
export async function getUserSubscription(userId: string) {
  try {
    const { data, error } = await supabase
      .from("subscriptions")
      .select("*, plans(*)")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .single()

    if (error) {
      if (error.code === "PGRST116") {
        // PGRST116 significa que no se encontró ningún registro
        return null
      }
      console.error("Error fetching subscription:", error)
      throw error
    }

    return data
  } catch (error) {
    console.error("Get subscription exception:", error)
    return null
  }
}

// Verificar si el usuario tiene una suscripción activa
export async function hasActiveSubscription(userId: string): Promise<boolean> {
  try {
    const subscription = await getUserSubscription(userId)

    if (!subscription) {
      return false
    }

    // Verificar si la suscripción está activa
    if (subscription.status === "active" || subscription.status === "trialing") {
      // Verificar que la suscripción no haya expirado
      const currentPeriodEnd = new Date(subscription.current_period_end)
      const now = new Date()

      if (currentPeriodEnd > now) {
        return true
      }
    }

    return false
  } catch (error) {
    console.error("Has active subscription error:", error)
    return false
  }
}

// Crear una suscripción de prueba gratuita
export async function createFreeTrial(userId: string) {
  try {
    // Verificar si ya tiene una suscripción
    const existingSubscription = await getUserSubscription(userId)
    if (existingSubscription) {
      return { success: true, data: existingSubscription }
    }

    // Obtener el plan de prueba gratuita
    const { data: trialPlan, error: planError } = await supabase
      .from("plans")
      .select("*")
      .eq("name", "Free Trial")
      .single()

    if (planError || !trialPlan) {
      console.error("Trial plan not found:", planError)
      return { success: false, error: "Trial plan not found" }
    }

    // Crear una fecha de inicio (ahora) y una fecha de fin (3 días después)
    const startDate = new Date()
    const endDate = new Date()
    endDate.setDate(endDate.getDate() + 3)

    // Crear la suscripción
    const { data, error } = await supabase.from("subscriptions").insert({
      user_id: userId,
      plan_id: trialPlan.id,
      status: "trialing",
      current_period_start: startDate.toISOString(),
      current_period_end: endDate.toISOString(),
      cancel_at_period_end: false,
    })

    if (error) {
      console.error("Error creating free trial:", error)
      return { success: false, error: error.message }
    }

    return { success: true, data }
  } catch (error) {
    console.error("Create free trial exception:", error)
    return { success: false, error: "Failed to create free trial" }
  }
}

// Actualizar la suscripción desde Stripe
export async function updateSubscriptionFromStripe(
  stripeSubscriptionId: string,
  status: string,
  currentPeriodStart: string,
  currentPeriodEnd: string,
  cancelAtPeriodEnd: boolean,
) {
  try {
    const { data, error } = await supabase
      .from("subscriptions")
      .update({
        status,
        current_period_start: currentPeriodStart,
        current_period_end: currentPeriodEnd,
        cancel_at_period_end: cancelAtPeriodEnd,
        updated_at: new Date().toISOString(),
      })
      .eq("stripe_subscription_id", stripeSubscriptionId)

    if (error) {
      console.error("Error updating subscription:", error)
      return { success: false, error }
    }

    return { success: true, data }
  } catch (error) {
    console.error("Update subscription exception:", error)
    return { success: false, error: "Failed to update subscription" }
  }
}

// Obtener todos los planes disponibles
export async function getAvailablePlans() {
  try {
    const { data, error } = await supabase.from("plans").select("*").order("price", { ascending: true })

    if (error) {
      console.error("Error fetching plans:", error)
      return []
    }

    return data || []
  } catch (error) {
    console.error("Get plans exception:", error)
    return []
  }
}
