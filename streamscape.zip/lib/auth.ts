import { supabase } from "./supabase"

export type AuthError = {
  message: string
}

export type AuthResponse = {
  success: boolean
  error: AuthError | null
  data: any | null
}

// Registro de usuario simplificado
export async function signUp(
  email: string,
  password: string,
  firstName: string,
  lastName: string,
): Promise<AuthResponse> {
  try {
    console.log("🚀 Iniciando registro de usuario:", { email, firstName, lastName })

    // Crear el usuario en Supabase Auth
    // El trigger automáticamente creará el perfil
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          first_name: firstName,
          last_name: lastName,
          full_name: `${firstName} ${lastName}`,
        },
      },
    })

    if (authError) {
      console.error("❌ Error de autenticación:", authError)

      // Manejar errores específicos
      if (authError.message.includes("30 seconds")) {
        return {
          success: false,
          error: { message: "Por favor espera 30 segundos antes de intentar registrarte de nuevo." },
          data: null,
        }
      }

      if (authError.message.includes("already registered")) {
        return {
          success: false,
          error: { message: "Este email ya está registrado. Intenta iniciar sesión en su lugar." },
          data: null,
        }
      }

      return {
        success: false,
        error: { message: authError.message },
        data: null,
      }
    }

    console.log("✅ Usuario de auth creado:", authData)

    if (authData.user) {
      console.log("👤 Usuario creado con ID:", authData.user.id)
      console.log("📧 Confirmación de email requerida:", !authData.session)

      // Si no hay sesión, significa que necesita confirmar email
      if (!authData.session) {
        return {
          success: true,
          error: null,
          data: {
            ...authData,
            needsEmailConfirmation: true,
          },
        }
      }

      // Si hay sesión, el usuario está listo para usar la app
      console.log("✅ Usuario registrado y autenticado exitosamente")
      return {
        success: true,
        error: null,
        data: authData,
      }
    }

    return {
      success: false,
      error: { message: "No se pudo crear el usuario. Por favor intenta de nuevo." },
      data: null,
    }
  } catch (error) {
    console.error("💥 Excepción general en signup:", error)
    return {
      success: false,
      error: {
        message: `Error general: ${error instanceof Error ? error.message : "Error desconocido"}`,
      },
      data: null,
    }
  }
}

// Inicio de sesión
export async function signIn(email: string, password: string): Promise<AuthResponse> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      console.error("Sign in error:", error)
      return {
        success: false,
        error: { message: error.message },
        data: null,
      }
    }

    return {
      success: true,
      error: null,
      data,
    }
  } catch (error) {
    console.error("Sign in exception:", error)
    return {
      success: false,
      error: { message: "An unexpected error occurred during sign in." },
      data: null,
    }
  }
}

// Reenviar email de confirmación
export async function resendConfirmation(email: string): Promise<AuthResponse> {
  try {
    const { error } = await supabase.auth.resend({
      type: "signup",
      email,
    })

    if (error) {
      return {
        success: false,
        error: { message: error.message },
        data: null,
      }
    }

    return {
      success: true,
      error: null,
      data: null,
    }
  } catch (error) {
    return {
      success: false,
      error: { message: "Error reenviando confirmación" },
      data: null,
    }
  }
}

// Cerrar sesión
export async function signOut(): Promise<AuthResponse> {
  try {
    const { error } = await supabase.auth.signOut()

    if (error) {
      return {
        success: false,
        error: { message: error.message },
        data: null,
      }
    }

    return {
      success: true,
      error: null,
      data: null,
    }
  } catch (error) {
    return {
      success: false,
      error: { message: "An unexpected error occurred during sign out." },
      data: null,
    }
  }
}

// Obtener usuario actual
export async function getCurrentUser() {
  try {
    const { data, error } = await supabase.auth.getUser()

    if (error) {
      console.error("Get user error:", error)
      return null
    }

    return data?.user || null
  } catch (error) {
    console.error("Get user exception:", error)
    return null
  }
}
