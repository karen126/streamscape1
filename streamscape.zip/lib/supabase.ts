import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl) {
  throw new Error("Missing env.NEXT_PUBLIC_SUPABASE_URL")
}

if (!supabaseAnonKey) {
  throw new Error("Missing env.NEXT_PUBLIC_SUPABASE_ANON_KEY")
}

console.log("🔧 Supabase configurado:", {
  url: supabaseUrl.substring(0, 30) + "...",
  hasAnonKey: !!supabaseAnonKey,
  anonKeyLength: supabaseAnonKey?.length,
})

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
  },
})

// Test de conexión
export async function testSupabaseConnection() {
  try {
    console.log("🧪 Probando conexión a Supabase...")

    // Test básico de conexión
    const { data, error } = await supabase.from("profiles").select("count", { count: "exact", head: true })

    if (error) {
      console.error("❌ Error de conexión:", error)
      return { success: false, error: error.message }
    }

    console.log("✅ Conexión a Supabase exitosa")
    return { success: true, data }
  } catch (error) {
    console.error("💥 Excepción probando conexión:", error)
    return { success: false, error: error instanceof Error ? error.message : "Error desconocido" }
  }
}
