import { supabase } from "./supabase"
import { v4 as uuidv4 } from "uuid"

// Obtener perfil de usuario
export async function getProfile(userId: string) {
  const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single()

  if (error) {
    console.error("Error fetching profile:", error)
    return null
  }

  return data
}

// Actualizar perfil de usuario
export async function updateProfile(userId: string, profileData: any) {
  const { data, error } = await supabase
    .from("profiles")
    .update({
      ...profileData,
      updated_at: new Date().toISOString(),
    })
    .eq("id", userId)

  if (error) {
    console.error("Error updating profile:", error)
    return { success: false, error }
  }

  return { success: true, data }
}

// Obtener usuarios para mostrar en Discover
export async function getDiscoverUsers(currentUserId: string, limit = 10) {
  // Obtén los IDs de los usuarios con los que ya hay match
  const { data: matchData } = await supabase
    .from("matches")
    .select("user1_id, user2_id")
    .or(`user1_id.eq.${currentUserId},user2_id.eq.${currentUserId}`)

  // Crear un array de IDs de usuarios con los que ya hay match
  const matchedUserIds = matchData
    ? matchData.map((match) => {
        return match.user1_id === currentUserId ? match.user2_id : match.user1_id
      })
    : []

  // Añadir el ID del usuario actual a la lista de exclusión
  matchedUserIds.push(currentUserId)

  // Obtener usuarios que no están en la lista de exclusión
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .not("id", "in", `(${matchedUserIds.join(",")})`)
    .order("created_at", { ascending: false })
    .limit(limit)

  if (error) {
    console.error("Error fetching discover users:", error)
    return []
  }

  return data || []
}

// Crear un match
export async function createMatch(userId: string, otherUserId: string) {
  // Verificar si ya existe un match
  const { data: existingMatch } = await supabase
    .from("matches")
    .select("*")
    .or(`and(user1_id.eq.${userId},user2_id.eq.${otherUserId}),and(user1_id.eq.${otherUserId},user2_id.eq.${userId})`)
    .single()

  if (existingMatch) {
    // Si ya existe un match, no hacer nada
    return { success: true, data: existingMatch }
  }

  // Crear un nuevo match
  const { data, error } = await supabase.from("matches").insert({
    id: uuidv4(),
    user1_id: userId,
    user2_id: otherUserId,
    status: "pending", // El estado puede ser 'pending' o 'matched'
  })

  if (error) {
    console.error("Error creating match:", error)
    return { success: false, error }
  }

  return { success: true, data }
}

// Verificar si hay un match mutuo
export async function checkForMutualMatch(userId: string, otherUserId: string) {
  // Verificar si el otro usuario también ha dado like
  const { data, error } = await supabase
    .from("matches")
    .select("*")
    .eq("user1_id", otherUserId)
    .eq("user2_id", userId)
    .single()

  if (error && error.code !== "PGRST116") {
    // PGRST116 significa que no se encontró ningún registro, lo cual es esperado si no hay match
    console.error("Error checking for mutual match:", error)
    return { success: false, error }
  }

  if (data) {
    // Hay un match mutuo, actualizar ambos registros a 'matched'
    await supabase.from("matches").update({ status: "matched" }).eq("id", data.id)

    // También actualizar el match creado por el usuario actual
    const { data: myMatchData } = await supabase
      .from("matches")
      .select("*")
      .eq("user1_id", userId)
      .eq("user2_id", otherUserId)
      .single()

    if (myMatchData) {
      await supabase.from("matches").update({ status: "matched" }).eq("id", myMatchData.id)
    }

    // Crear un chat para que puedan comunicarse
    const chatId = uuidv4()
    await supabase.from("chats").insert({
      id: chatId,
      user1_id: userId,
      user2_id: otherUserId,
    })

    return { success: true, isMatch: true, chatId }
  }

  return { success: true, isMatch: false }
}

// Obtener matches del usuario
export async function getUserMatches(userId: string) {
  // Obtener matches donde el usuario es user1
  const { data: matches1, error: error1 } = await supabase
    .from("matches")
    .select(`
      id,
      user2_id,
      status,
      created_at,
      profiles:user2_id(*)
    `)
    .eq("user1_id", userId)
    .eq("status", "matched")

  // Obtener matches donde el usuario es user2
  const { data: matches2, error: error2 } = await supabase
    .from("matches")
    .select(`
      id,
      user1_id,
      status,
      created_at,
      profiles:user1_id(*)
    `)
    .eq("user2_id", userId)
    .eq("status", "matched")

  if (error1 || error2) {
    console.error("Error fetching matches:", error1 || error2)
    return []
  }

  // Combinar los resultados
  const allMatches = [
    ...(matches1
      ? matches1.map((match) => ({
          id: match.id,
          otherUserId: match.user2_id,
          profile: match.profiles,
          status: match.status,
          created_at: match.created_at,
        }))
      : []),
    ...(matches2
      ? matches2.map((match) => ({
          id: match.id,
          otherUserId: match.user1_id,
          profile: match.profiles,
          status: match.status,
          created_at: match.created_at,
        }))
      : []),
  ]

  return allMatches
}

// Obtener chats del usuario
export async function getUserChats(userId: string) {
  // Obtener chats donde el usuario es user1
  const { data: chats1, error: error1 } = await supabase
    .from("chats")
    .select(`
      id,
      created_at,
      updated_at,
      user2_id,
      profiles:user2_id(*)
    `)
    .eq("user1_id", userId)

  // Obtener chats donde el usuario es user2
  const { data: chats2, error: error2 } = await supabase
    .from("chats")
    .select(`
      id,
      created_at,
      updated_at,
      user1_id,
      profiles:user1_id(*)
    `)
    .eq("user2_id", userId)

  if (error1 || error2) {
    console.error("Error fetching chats:", error1 || error2)
    return []
  }

  // Para cada chat, obtener el último mensaje
  const allChats = [
    ...(chats1 || []).map((chat) => ({
      id: chat.id,
      otherUserId: chat.user2_id,
      otherUserProfile: chat.profiles,
      updated_at: chat.updated_at,
      created_at: chat.created_at,
    })),
    ...(chats2 || []).map((chat) => ({
      id: chat.id,
      otherUserId: chat.user1_id,
      otherUserProfile: chat.profiles,
      updated_at: chat.updated_at,
      created_at: chat.created_at,
    })),
  ]

  // Obtener el último mensaje para cada chat
  const chatsWithLastMessage = await Promise.all(
    allChats.map(async (chat) => {
      const { data: messages } = await supabase
        .from("messages")
        .select("*")
        .eq("chat_id", chat.id)
        .order("created_at", { ascending: false })
        .limit(1)

      return {
        ...chat,
        lastMessage: messages && messages.length > 0 ? messages[0] : null,
      }
    }),
  )

  return chatsWithLastMessage
}

// Obtener mensajes de un chat
export async function getChatMessages(chatId: string) {
  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .eq("chat_id", chatId)
    .order("created_at", { ascending: true })

  if (error) {
    console.error("Error fetching chat messages:", error)
    return []
  }

  return data || []
}

// Enviar un mensaje
export async function sendMessage(chatId: string, senderId: string, content: string) {
  const { data, error } = await supabase.from("messages").insert({
    id: uuidv4(),
    chat_id: chatId,
    sender_id: senderId,
    content,
    read: false,
  })

  if (error) {
    console.error("Error sending message:", error)
    return { success: false, error }
  }

  // Actualizar la fecha de actualización del chat
  await supabase.from("chats").update({ updated_at: new Date().toISOString() }).eq("id", chatId)

  return { success: true, data }
}

// Marcar mensajes como leídos
export async function markMessagesAsRead(chatId: string, userId: string) {
  const { data, error } = await supabase
    .from("messages")
    .update({ read: true })
    .eq("chat_id", chatId)
    .not("sender_id", "eq", userId)

  if (error) {
    console.error("Error marking messages as read:", error)
    return { success: false, error }
  }

  return { success: true, data }
}
